from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import Column, Integer, String, Date, select

DATABASE_URL = "postgresql+asyncpg://user:password@localhost:5432/comicstore" 

Base = declarative_base()
engine = create_async_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

# Define your Orders table as a Python class (ORM)
class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    order_id = Column(Integer, index=True)
    order_date = Column(Date)
    customer_id = Column(String)
    customer_name = Column(String)
    book_id = Column(String)
    book_title = Column(String)
    quantity = Column(Integer)

# For request/response data (validation)
class OrderSchema(BaseModel):
    order_id: int
    order_date: str   # e.g. "2025-06-10"
    customer_id: str
    customer_name: str
    book_id: str
    book_title: str
    quantity: int
    class Config:
        orm_mode = True

class UpdateOrderSchema(BaseModel):
    quantity: Optional[int] = None

app = FastAPI()

async def get_db():
    async with SessionLocal() as session:
        yield session

# GET: Get all orders
@app.get("/orders", response_model=List[OrderSchema])
async def read_orders(db=Depends(get_db)):
    result = await db.execute(select(Order))
    return result.scalars().all()

# POST: Create a new order
@app.post("/orders", response_model=OrderSchema)
async def create_order(order: OrderSchema, db=Depends(get_db)):
    new_order = Order(**order.dict())
    db.add(new_order)
    await db.commit()
    await db.refresh(new_order)
    return new_order

# PATCH: Update order quantity
@app.patch("/orders/{order_id}", response_model=OrderSchema)
async def update_order(order_id: int, update: UpdateOrderSchema, db=Depends(get_db)):
    result = await db.execute(select(Order).where(Order.order_id == order_id))
    order = result.scalar_one_or_none()
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    if update.quantity is not None:
        order.quantity = update.quantity
    await db.commit()
    await db.refresh(order)
    return order

# DELETE: Delete an order
@app.delete("/orders/{order_id}")
async def delete_order(order_id: int, db=Depends(get_db)):
    result = await db.execute(select(Order).where(Order.order_id == order_id))
    order = result.scalar_one_or_none()
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    await db.delete(order)
    await db.commit()
    return {"detail": "Order deleted"}
